
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const app = express();

app.use(express.json());
app.use(cors());

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'banner_db'
});

app.get('/api/banner', (req, res) => {
  db.query('SELECT * FROM banners WHERE id = 1', (err, result) => {
    if (err) throw err;
    res.json(result[0]);
  });
});

app.post('/api/banner', (req, res) => {
  const { description, timer, link, isVisible } = req.body;
  db.query(
    'UPDATE banners SET description = ?, timer = ?, link = ?, isVisible = ? WHERE id = 1',
    [description, timer, link, isVisible],
    (err, result) => {
      if (err) throw err;
      res.send('Banner updated');
    }
  );
});

app.listen(5000, () => console.log('Server running on port 5000'));
    