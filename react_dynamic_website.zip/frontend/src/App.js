
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import moment from 'moment';

function Banner() {
  const [banner, setBanner] = useState({});
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    axios.get('http://localhost:5000/api/banner').then((response) => {
      setBanner(response.data);
      setTimeLeft(response.data.timer);
    });

    const interval = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  if (!banner.isVisible || timeLeft <= 0) return null;

  return (
    <div className="banner">
      <p>{banner.description}</p>
      <p>{moment.utc(timeLeft * 1000).format('HH:mm:ss')}</p>
      <a href={banner.link}>Click Here</a>
    </div>
  );
}

function Dashboard() {
  const [formData, setFormData] = useState({
    description: '',
    timer: 60,
    link: '',
    isVisible: true,
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('http://localhost:5000/api/banner', formData).then((response) => {
      alert('Banner updated successfully!');
    });
  };

  return (
    <div className="dashboard">
      <form onSubmit={handleSubmit}>
        <label>Description:</label>
        <input
          type="text"
          name="description"
          value={formData.description}
          onChange={handleChange}
        />
        <label>Timer (seconds):</label>
        <input
          type="number"
          name="timer"
          value={formData.timer}
          onChange={handleChange}
        />
        <label>Link:</label>
        <input
          type="text"
          name="link"
          value={formData.link}
          onChange={handleChange}
        />
        <label>Visibility:</label>
        <input
          type="checkbox"
          name="isVisible"
          checked={formData.isVisible}
          onChange={() =>
            setFormData({ ...formData, isVisible: !formData.isVisible })
          }
        />
        <button type="submit">Update Banner</button>
      </form>
    </div>
  );
}

function App() {
  return (
    <div className="App">
      <Banner />
      <Dashboard />
    </div>
  );
}

export default App;
    